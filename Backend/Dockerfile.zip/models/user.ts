export class User {
  firstName: string;
  lastName: string;
  password: string;
  email: string;
  phone: string;
}
