export class AuthDto {
  email: string;
  password: string;
}
