export class Switch {
  date: string;
  owner: { _id: string; phone: string; fullName: string };

  phone: string;
  endHour: string;
  startHour: string;
  flexible: boolean;
  isTake: boolean;
  _id?: string;
}
