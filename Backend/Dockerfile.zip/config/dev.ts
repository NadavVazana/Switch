export const config = {
  dbURL: process.env["DB_URL"],
  // dbURL: "mongodb://nadav:1234@localhost:27017",
};
