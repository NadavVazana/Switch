export const config = {
  dbURL: process.env["DB_URL"],
};
